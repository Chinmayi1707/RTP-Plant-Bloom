require('dotenv').config();
const express = require('express');
const app = express();
const cors = require('cors');
const fs = require('fs');
const path = require('path');

app.use(cors());
app.use(express.json());
app.use(express.static(path.join(__dirname, 'public'), { index: false }));

app.get('/', (req, res) => {
  res.sendFile(path.join(__dirname, 'public', '1login.html'));
});


const authRoutes = require('./routes/auth');
const plantRoutes = require('./routes/plants');

app.use('/api', authRoutes);
app.use('/api/plants', plantRoutes);


console.log('Plant routes loaded');



// Start server
const PORT = process.env.PORT || 5000;
app.listen(PORT, () => {
  console.log(`Server running on http://localhost:${PORT}`);
});

